/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     10-Apr-22 18:32:23                           */
/*==============================================================*/


drop table if exists CASOVI;

drop table if exists ENGLESKI_JEZIK;

drop table if exists FRANCUSKI_JEZIK;

drop table if exists GRUPA;

drop table if exists ISPIT;

drop table if exists KURS;

drop table if exists NACIN_PLACANJA;

drop table if exists NEMACKI_JEZIK;

drop table if exists NIVO;

drop table if exists PLACANJE;

drop table if exists PROFESOR;

drop table if exists RACUN;

drop table if exists RUSKI_JEZIK;

drop table if exists SERTIFIKAT;

drop table if exists SKOLA_STRANIH_JEZIKA;

drop table if exists STRANI_JEZICI;

drop table if exists TERMIN;

drop table if exists UCENIK;

drop table if exists UCIONICA;

drop table if exists ZAPOSLENI;

/*==============================================================*/
/* Table: CASOVI                                                */
/*==============================================================*/
create table CASOVI
(
   ID_GRUPE             int not null,
   ID_UCIONICE          int not null,
   SMENA                varchar(10) not null,
   ID_CASA              int not null,
   primary key (ID_GRUPE, ID_UCIONICE, SMENA, ID_CASA)
);

/*==============================================================*/
/* Table: ENGLESKI_JEZIK                                        */
/*==============================================================*/
create table ENGLESKI_JEZIK
(
   ID_ENGLESKI          int not null,
   primary key (ID_ENGLESKI)
);

/*==============================================================*/
/* Table: FRANCUSKI_JEZIK                                       */
/*==============================================================*/
create table FRANCUSKI_JEZIK
(
   ID_FRANCUSKI         int not null,
   primary key (ID_FRANCUSKI)
);

/*==============================================================*/
/* Table: GRUPA                                                 */
/*==============================================================*/
create table GRUPA
(
   ID_GRUPE             int not null,
   primary key (ID_GRUPE)
);

/*==============================================================*/
/* Table: ISPIT                                                 */
/*==============================================================*/
create table ISPIT
(
   ID_SERTIFIKATA       int not null,
   ID_UCENIKA           int not null,
   ID_ISPITA            int not null,
   DATUM_ISPITA         date not null,
   OCENA                int not null,
   primary key (ID_SERTIFIKATA, ID_UCENIKA, ID_ISPITA)
);

/*==============================================================*/
/* Table: KURS                                                  */
/*==============================================================*/
create table KURS
(
   ID_KURSA             int not null,
   ID_JEZIKA            int not null,
   primary key (ID_KURSA)
);

/*==============================================================*/
/* Table: NACIN_PLACANJA                                        */
/*==============================================================*/
create table NACIN_PLACANJA
(
   ID_NPLACANJA         int not null,
   PLACANJE_RATE        varchar(5) not null,
   PLACANJE_ODJEDNOM    varchar(5) not null,
   primary key (ID_NPLACANJA)
);

/*==============================================================*/
/* Table: NEMACKI_JEZIK                                         */
/*==============================================================*/
create table NEMACKI_JEZIK
(
   ID_NEMACKI           int not null,
   primary key (ID_NEMACKI)
);

/*==============================================================*/
/* Table: NIVO                                                  */
/*==============================================================*/
create table NIVO
(
   VRSTA_NIVOA          varchar(2) not null,
   primary key (VRSTA_NIVOA)
);

/*==============================================================*/
/* Table: PLACANJE                                              */
/*==============================================================*/
create table PLACANJE
(
   ID_PLACANJA          int not null,
   ID_NPLACANJA         int not null,
   primary key (ID_PLACANJA)
);

/*==============================================================*/
/* Table: PROFESOR                                              */
/*==============================================================*/
create table PROFESOR
(
   ID_PROFESORA         int not null,
   IME_PROFESORA        varchar(10) not null,
   PREZIME_PROFESORA    varchar(20) not null,
   primary key (ID_PROFESORA)
);

/*==============================================================*/
/* Table: RACUN                                                 */
/*==============================================================*/
create table RACUN
(
   ID_PLACANJA          int not null,
   ID_UCENIKA           int not null,
   ID_RACUNA            int not null,
   CENA_SKOLARINE       int not null,
   primary key (ID_PLACANJA, ID_UCENIKA, ID_RACUNA)
);

/*==============================================================*/
/* Table: RUSKI_JEZIK                                           */
/*==============================================================*/
create table RUSKI_JEZIK
(
   ID_RUSKI             int not null,
   primary key (ID_RUSKI)
);

/*==============================================================*/
/* Table: SERTIFIKAT                                            */
/*==============================================================*/
create table SERTIFIKAT
(
   ID_SERTIFIKATA       int not null,
   primary key (ID_SERTIFIKATA)
);

/*==============================================================*/
/* Table: SKOLA_STRANIH_JEZIKA                                  */
/*==============================================================*/
create table SKOLA_STRANIH_JEZIKA
(
   ID_SKOLE             int not null,
   ID_GRUPE             int,
   ID_UCIONICE          int,
   SMENA                varchar(10),
   ID_CASA              int,
   ID_ZAPOSLENOG        int not null,
   ID_PROFESORA         int not null,
   ID_JEZIKA            int,
   NAZIV_SKOLE          varchar(50) not null,
   ADRESA_SKOLE         varchar(50) not null,
   KONTAKT              int,
   primary key (ID_SKOLE)
);

/*==============================================================*/
/* Table: STRANI_JEZICI                                         */
/*==============================================================*/
create table STRANI_JEZICI
(
   ID_JEZIKA            int not null,
   ID_FRANCUSKI         int,
   ID_ENGLESKI          int,
   ID_RUSKI             int,
   ID_NEMACKI           int,
   NAZIV_JEZIKA         varchar(20),
   primary key (ID_JEZIKA)
);

/*==============================================================*/
/* Table: TERMIN                                                */
/*==============================================================*/
create table TERMIN
(
   SMENA                varchar(10) not null,
   primary key (SMENA)
);

/*==============================================================*/
/* Table: UCENIK                                                */
/*==============================================================*/
create table UCENIK
(
   ID_UCENIKA           int not null,
   VRSTA_NIVOA          varchar(2) not null,
   ID_SKOLE             int not null,
   ID_KURSA             int not null,
   IME_UCENIKA          varchar(10) not null,
   PREZIME_UCENIKA      longtext not null,
   GODINE_UCENIKA       int not null,
   primary key (ID_UCENIKA)
);

/*==============================================================*/
/* Table: UCIONICA                                              */
/*==============================================================*/
create table UCIONICA
(
   ID_UCIONICE          int not null,
   primary key (ID_UCIONICE)
);

/*==============================================================*/
/* Table: ZAPOSLENI                                             */
/*==============================================================*/
create table ZAPOSLENI
(
   ID_ZAPOSLENOG        int not null,
   IME_ZAPOSLENOG       varchar(10) not null,
   PREZIME_ZAPOSLENOG   varchar(20) not null,
   primary key (ID_ZAPOSLENOG)
);

alter table CASOVI add constraint FK_KOJE_GRUPE_IMAJU_CAS foreign key (ID_GRUPE)
      references GRUPA (ID_GRUPE) on delete restrict on update restrict;

alter table CASOVI add constraint FK_U_KOJOJ_SMENI_SE_ODRZAVA_CAS foreign key (SMENA)
      references TERMIN (SMENA) on delete restrict on update restrict;

alter table CASOVI add constraint FK_U_KOJOJ_UCIONICI_SE_ODRZAVA_CAS foreign key (ID_UCIONICE)
      references UCIONICA (ID_UCIONICE) on delete restrict on update restrict;

alter table ISPIT add constraint FK_DA_LI_JE_UCENIK_POLAGAO_ISPIT foreign key (ID_UCENIKA)
      references UCENIK (ID_UCENIKA) on delete restrict on update restrict;

alter table ISPIT add constraint FK_ZA_KOJI_SERTIFIKAT_JE_POLAGAN_ISPIT foreign key (ID_SERTIFIKATA)
      references SERTIFIKAT (ID_SERTIFIKATA) on delete restrict on update restrict;

alter table KURS add constraint FK_JEZIK_KURSA foreign key (ID_JEZIKA)
      references STRANI_JEZICI (ID_JEZIKA) on delete restrict on update restrict;

alter table PLACANJE add constraint FK_NACIN_PLACANJA foreign key (ID_NPLACANJA)
      references NACIN_PLACANJA (ID_NPLACANJA) on delete restrict on update restrict;

alter table RACUN add constraint FK_DA_LI_JE_UCENIK_UPLATIO_RACUN foreign key (ID_UCENIKA)
      references UCENIK (ID_UCENIKA) on delete restrict on update restrict;

alter table RACUN add constraint FK_UPLATA_PO_CENOVNIKU foreign key (ID_PLACANJA)
      references PLACANJE (ID_PLACANJA) on delete restrict on update restrict;

alter table SKOLA_STRANIH_JEZIKA add constraint FK_CAS_KOJI_SE_ODRZAVA_U_SKOLI foreign key (ID_GRUPE, ID_UCIONICE, SMENA, ID_CASA)
      references CASOVI (ID_GRUPE, ID_UCIONICE, SMENA, ID_CASA) on delete restrict on update restrict;

alter table SKOLA_STRANIH_JEZIKA add constraint FK_PROFESORI_U_SKOLI foreign key (ID_PROFESORA)
      references PROFESOR (ID_PROFESORA) on delete restrict on update restrict;

alter table SKOLA_STRANIH_JEZIKA add constraint FK_VRSTE_JEZIKA_U_SKOLI foreign key (ID_JEZIKA)
      references STRANI_JEZICI (ID_JEZIKA) on delete restrict on update restrict;

alter table SKOLA_STRANIH_JEZIKA add constraint FK_ZAPOSLENI_U_SKOLI foreign key (ID_ZAPOSLENOG)
      references ZAPOSLENI (ID_ZAPOSLENOG) on delete restrict on update restrict;

alter table STRANI_JEZICI add constraint FK_ENGLESKI_JEZIK foreign key (ID_ENGLESKI)
      references ENGLESKI_JEZIK (ID_ENGLESKI) on delete restrict on update restrict;

alter table STRANI_JEZICI add constraint FK_FRANCUSKI_JEZIK foreign key (ID_FRANCUSKI)
      references FRANCUSKI_JEZIK (ID_FRANCUSKI) on delete restrict on update restrict;

alter table STRANI_JEZICI add constraint FK_NEMACKI_JEZIK foreign key (ID_NEMACKI)
      references NEMACKI_JEZIK (ID_NEMACKI) on delete restrict on update restrict;

alter table STRANI_JEZICI add constraint FK_RUSKI_JEZIK foreign key (ID_RUSKI)
      references RUSKI_JEZIK (ID_RUSKI) on delete restrict on update restrict;

alter table UCENIK add constraint FK_KOJI_KURS_SLUSA_UCENIK foreign key (ID_KURSA)
      references KURS (ID_KURSA) on delete restrict on update restrict;

alter table UCENIK add constraint FK_KOM_NIVOU_PRIPADA_UCENIK foreign key (VRSTA_NIVOA)
      references NIVO (VRSTA_NIVOA) on delete restrict on update restrict;

alter table UCENIK add constraint FK_UCENICI_U_SKOLI foreign key (ID_SKOLE)
      references SKOLA_STRANIH_JEZIKA (ID_SKOLE) on delete restrict on update restrict;

